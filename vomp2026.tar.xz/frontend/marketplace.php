<?php
$pageTitle = 'Marketplace - VomP';
ob_start();
?>
<section class="py-8 md:py-12">
    <!-- Header -->
    <div class="mb-8">
        <p class="text-xs uppercase tracking-[0.2em] font-black text-[#ff610a] mb-2">Browse Products</p>
        <h1 class="text-4xl md:text-5xl font-black text-white tracking-tight mb-2">Marketplace</h1>
        <p class="text-gray-400">Discover products from stores across Nigeria.</p>
    </div>

    <!-- Search Bar -->
    <form method="GET" action="/marketplace" class="mb-6">
        <div class="relative max-w-xl">
            <input type="text" name="q" value="<?php echo htmlspecialchars($searchQuery ?? ''); ?>" placeholder="Search products or stores..." class="w-full rounded-xl px-5 py-3.5 pl-12 bg-transparent border border-white/10 focus:border-[#ff610a] focus:outline-none text-white placeholder-gray-500 transition-colors" />
            <svg class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" /></svg>
            <?php if ($searchQuery): ?>
                <a href="/marketplace" class="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full text-gray-500 hover:text-white transition-colors">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                </a>
            <?php endif; ?>
        </div>
    </form>

    <?php if ($searchQuery): ?>
        <p class="text-sm text-gray-400 mb-6">
            Search results for "<strong class="text-white"><?php echo htmlspecialchars($searchQuery); ?></strong>"
            — <?php echo count($allProducts); ?> product<?php echo count($allProducts) !== 1 ? 's' : ''; ?>
            <?php if ($searchStores): ?>
                , <?php echo count($searchStores); ?> store<?php echo count($searchStores) !== 1 ? 's' : ''; ?>
            <?php endif; ?>
        </p>
    <?php endif; ?>

    <!-- Category Pills -->
    <div class="flex flex-wrap gap-2 mb-8">
        <a href="/marketplace"
           class="px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all border <?php echo !$activeCategory ? 'bg-[#ff610a] text-white border-[#ff610a]' : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10 hover:text-white'; ?>">
            All
        </a>
        <?php foreach ($categories as $cat): ?>
            <a href="/marketplace?category=<?php echo urlencode($cat); ?>"
               class="px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all border <?php echo $activeCategory === $cat ? 'bg-[#ff610a] text-white border-[#ff610a]' : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10 hover:text-white'; ?>">
                <?php echo htmlspecialchars($cat); ?>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Products Grid -->
    <?php if (empty($allProducts)): ?>
        <div class="text-center py-16">
            <div class="w-20 h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-6">
                <svg class="w-10 h-10 text-gray-500" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5m6 4.125l2.25 2.25m0 0l2.25 2.25M12 11.625l2.25-2.25M12 11.625l-2.25 2.25M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" /></svg>
            </div>
            <h2 class="text-2xl font-black text-white mb-2">No Products Found</h2>
            <p class="text-gray-400"><?php echo $activeCategory ? 'No products in this category yet.' : 'No products available yet.'; ?></p>
            <?php if (empty($currentUser)): ?>
                <a href="/register" class="inline-block mt-6 px-6 py-3 rounded-2xl bg-[#ff610a] text-white font-black hover:bg-[#e05500] transition-all">Start Selling</a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            <?php foreach ($allProducts as $p): ?>
                <a href="/store/<?php echo htmlspecialchars($p['store_slug']); ?>/<?php echo htmlspecialchars($p['id']); ?>" class="glass-morphism rounded-2xl border border-white/10 overflow-hidden hover:bg-white/[0.03] transition-all group">
                    <div class="aspect-square skeleton-box relative overflow-hidden">
                        <?php if (!empty($p['media_url'])): ?>
                            <img src="<?php echo htmlspecialchars($p['media_url']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" class="img-skeleton w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" onload="this.parentElement.classList.remove('skeleton-box');this.classList.add('loaded')" />
                        <?php else: ?>
                            <div class="w-full h-full flex items-center justify-center text-gray-600">
                                <svg class="w-12 h-12" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.41a2.25 2.25 0 013.182 0l2.909 2.91m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>
                            </div>
                        <?php endif; ?>
                        <div class="absolute top-2 left-2">
                            <span class="px-2 py-0.5 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-[10px] font-black uppercase tracking-wider">In Stock</span>
                        </div>
                    </div>
                    <div class="p-3 md:p-4">
                        <p class="text-sm md:text-lg font-black text-white mb-1">₦<?php echo number_format((float)$p['price']); ?></p>
                        <p class="text-xs md:text-sm text-gray-300 font-semibold truncate mb-1"><?php echo htmlspecialchars($p['name']); ?></p>
                        <div class="flex items-center gap-1 text-[10px] md:text-xs text-gray-500">
                            <svg class="w-3 h-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13.5 21v-7.5a.75.75 0 01.75-.75h3a.75.75 0 01.75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349m-16.5 11.65V9.35m0 0a3.001 3.001 0 003.75-.615A2.993 2.993 0 009.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 002.25 1.016c.896 0 1.7-.393 2.25-1.016a3.001 3.001 0 003.75.614m-16.5 0a3.004 3.004 0 01-.621-4.72L4.318 3.44A1.5 1.5 0 015.378 3h13.243a1.5 1.5 0 011.06.44l1.19 1.189a3 3 0 01-.621 4.72m-13.5 8.65h3.75a.75.75 0 00.75-.75V13.5a.75.75 0 00-.75-.75H6.75a.75.75 0 00-.75.75v3.75c0 .415.336.75.75.75z" /></svg>
                            <span class="truncate"><?php echo htmlspecialchars($p['store_name']); ?></span>
                        </div>
                        <?php if (!empty($p['location'])): ?>
                            <p class="text-[10px] text-gray-600 mt-0.5"><?php echo htmlspecialchars($p['location']); ?></p>
                        <?php endif; ?>
                        <?php if (!empty($p['product_condition'])): ?>
                            <p class="text-[10px] text-gray-600 mt-0.5"><?php echo htmlspecialchars($p['product_condition']); ?></p>
                        <?php endif; ?>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Searched Stores (when searching) -->
    <?php if (!empty($searchStores)): ?>
        <section class="mt-10 mb-10">
            <h2 class="text-2xl font-black text-white tracking-tight mb-4">Stores</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php foreach ($searchStores as $s):
                    $availableCount = count(array_filter(product_get_products_by_store($s['id']), fn($p) => (int)$p['is_available'] === 1));
                ?>
                    <a href="/store/<?php echo htmlspecialchars($s['slug']); ?>" class="glass-morphism rounded-2xl p-5 border border-white/10 hover:bg-white/[0.03] transition-all group">
                        <div class="flex items-center gap-3 mb-3">
                            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-[#ff610a] to-purple-600 flex items-center justify-center text-white font-black shadow-lg shadow-[#ff610a]/20 flex-shrink-0 text-lg">
                                <?php echo strtoupper(substr(htmlspecialchars($s['name']), 0, 1)); ?>
                            </div>
                            <div class="min-w-0">
                                <h3 class="font-black text-white group-hover:text-[#ff610a] transition-colors truncate"><?php echo htmlspecialchars($s['name']); ?></h3>
                                <p class="text-xs text-gray-500 font-bold uppercase tracking-wider"><?php echo $availableCount; ?> product<?php echo $availableCount !== 1 ? 's' : ''; ?></p>
                            </div>
                        </div>
                        <?php if (!empty($s['description'])): ?>
                            <p class="text-gray-400 text-sm leading-relaxed line-clamp-2"><?php echo htmlspecialchars($s['description']); ?></p>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- Explore Storefronts -->
    <?php if (!empty($stores)): ?>
        <section class="mt-16 md:mt-20">
            <div class="flex items-center justify-between mb-8">
                <div>
                    <p class="text-xs uppercase tracking-[0.2em] font-black text-[#ff610a] mb-1">Vendors</p>
                    <h2 class="text-3xl md:text-4xl font-black text-white tracking-tight">Explore Storefronts</h2>
                </div>
                <a href="/marketplace" class="hidden md:inline-flex items-center gap-2 text-xs text-[#ff610a] hover:text-[#ff8c3a] font-black uppercase tracking-wider transition-colors">
                    View All
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" /></svg>
                </a>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                <?php foreach ($stores as $s):
                    $productCount = count(product_get_products_by_store($s['id']));
                    $availableCount = count(array_filter(product_get_products_by_store($s['id']), fn($p) => (int)$p['is_available'] === 1));
                ?>
                    <a href="/store/<?php echo htmlspecialchars($s['slug']); ?>" class="glass-morphism rounded-2xl p-5 border border-white/10 hover:bg-white/[0.03] transition-all group">
                        <div class="flex items-center gap-3 mb-3">
                            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-[#ff610a] to-purple-600 flex items-center justify-center text-white font-black shadow-lg shadow-[#ff610a]/20 flex-shrink-0 text-lg">
                                <?php echo strtoupper(substr(htmlspecialchars($s['name']), 0, 1)); ?>
                            </div>
                            <div class="min-w-0">
                                <h3 class="font-black text-white group-hover:text-[#ff610a] transition-colors truncate"><?php echo htmlspecialchars($s['name']); ?></h3>
                                <p class="text-xs text-gray-500 font-bold uppercase tracking-wider"><?php echo $availableCount; ?> product<?php echo $availableCount !== 1 ? 's' : ''; ?></p>
                            </div>
                        </div>
                        <?php if (!empty($s['description'])): ?>
                            <p class="text-gray-400 text-sm leading-relaxed line-clamp-2"><?php echo htmlspecialchars($s['description']); ?></p>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>
</section>

<?php
$content = ob_get_clean();
?>
